﻿# Alarm Clock - 闹钟 APK 构建指南

## 项目结构
```
alarm-app/
├── android/          ← Android 原生项目
│   ├── build.gradle
│   ├── settings.gradle
│   ├── gradlew.bat
│   ├── build.py       (备用 Python 构建脚本)
│   ├── local.properties (SDK 路径)
│   ├── gradle/wrapper/
│   └── app/
│       ├── build.gradle
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── java/com/alarmclock/app/
│           │   ├── MainActivity.java      ← WebView + 闹钟入口
│           │   ├── AlarmReceiver.java     ← 广播接收器 (唤醒设备)
│           │   ├── AlarmService.java      ← 前台服务 (播放铃声+震动)
│           │   └── WebAppInterface.java   ← JS ↔ Java 桥接
│           ├── res/                       ← 资源文件
│           └── assets/                    ← 网页文件
├── outputs/          ← 原始网页版
├── package.json
└── capacitor.config.json
```

## 功能特性
- 三个 Tab：闹钟 / 计时器 / 秒表
- 闹钟支持每周重复 + 日历式指定日期多选
- 4 种铃声：经典 / 柔和 / 数码 / 蜂鸣
- 贪睡 5 分钟
- **锁屏自动亮屏响铃** (原生 Android AlarmManager)
- **震动 + 系统闹钟铃声**
- WebView 加载网页 UI，JavaScript ↔ Java 双向通信

## 构建 APK 步骤

### 方法一：用 Android Studio 打开 (推荐)

1. 打开 Android Studio
2. 点击 File → Open...
3. 选择 `alarm-app/android` 文件夹
4. 等待 Android Studio 自动下载 Gradle Wrapper 和 SDK
5. 点击右上角绿色 ▶️ Run 按钮
6. APK 会安装在连接的手机上或 Android 模拟器中
7. 或者 Build → Build Bundle(s) / APK(s) → Build APK(s)
8. APK 位置：`android/app/build/outputs/apk/debug/app-debug.apk`

### 方法二：命令行构建 (需先完成方法一的一次性同步)

```bash
cd alarm-app/android
./gradlew assembleDebug
```

## 第一次使用注意事项
1. 启动 App 时会请求"允许精确闹钟"权限 → 请点击允许
2. 会请求通知权限 → 请点击允许
3. 添加闹钟后，App 会把闹铃信息注册到 Android 系统 AlarmManager
4. 手机关屏后，到闹钟时间会自动唤醒、亮屏、响铃、震动
5. 点击"关闭"停止响铃，点击"贪睡"5 分钟后再次提醒
