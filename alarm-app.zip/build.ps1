﻿$env:JAVA_HOME = "F:\Program Files\Eclipse Adoptium\jdk-25.0.3.9-hotspot"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"
$env:ANDROID_SDK_ROOT = "$env:LOCALAPPDATA\Android\Sdk"

Write-Host "JAVA_HOME: $env:JAVA_HOME" -ForegroundColor Green
Write-Host "ANDROID_HOME: $env:ANDROID_HOME" -ForegroundColor Green

$projDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location (Join-Path $projDir "android")
Write-Host "Building APK..." -ForegroundColor Green

if (Test-Path "gradlew.bat") {
    .\gradlew.bat assembleDebug
} else {
    Write-Host "No gradlew.bat found. Please open the project in Android Studio first." -ForegroundColor Yellow
    Write-Host "It will generate the Gradle wrapper automatically."
}
