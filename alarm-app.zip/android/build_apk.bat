@echo off
set JAVA_HOME=F:\Program Files\Android\Android Studio\jbr
set PATH=%JAVA_HOME%\bin;%PATH%
set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk

echo ========================================
echo  Alarm Clock APK Builder
echo ========================================
echo.
echo JAVA_HOME: %JAVA_HOME%
echo ANDROID_HOME: %ANDROID_HOME%
echo.
echo Step 1: Clean build
call gradlew.bat clean
echo.
echo Step 2: Build APK
call gradlew.bat assembleDebug
echo.
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ===== BUILD SUCCESS =====
    echo APK location:
    echo app\build\outputs\apk\debug\app-debug.apk
    echo.
    pause
) else (
    echo.
    echo ===== BUILD FAILED =====
    echo Check the error messages above.
    pause
)
