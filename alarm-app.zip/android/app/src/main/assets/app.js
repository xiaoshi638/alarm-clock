﻿// --- Audio Engine ---
const AudioEngine = {
  ctx: null, gainNode: null, currentOsc: null, currentGain: null,
  _ensure() { if (!this.ctx) { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); this.gainNode = this.ctx.createGain(); this.gainNode.connect(this.ctx.destination); } if (this.ctx.state === 'suspended') this.ctx.resume(); },
  _playTone(freq, type, duration, delay = 0) { const osc = this.ctx.createOscillator(); const env = this.ctx.createGain(); osc.type = type; osc.frequency.setValueAtTime(freq, this.ctx.currentTime + delay); env.gain.setValueAtTime(0, this.ctx.currentTime + delay); env.gain.linearRampToValueAtTime(0.3, this.ctx.currentTime + delay + 0.04); env.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + delay + duration); osc.connect(env); env.connect(this.gainNode); osc.start(this.ctx.currentTime + delay); osc.stop(this.ctx.currentTime + delay + duration + 0.05); return osc; },
  startAlarm(sound = 'classic') { this._ensure(); this.stopAlarm(); const p = ({ classic: { type: 'sine', base: 800, pattern: [0, 0.15, 0.3, 0.45] }, gentle: { type: 'sine', base: 440, pattern: [0, 0.3, 0.6] }, digital: { type: 'square', base: 1000, pattern: [0, 0.1, 0.2, 0.35, 0.45] }, buzzer: { type: 'sawtooth', base: 200, pattern: [0, 0.08, 0.16] } })[sound] || { type: 'sine', base: 800, pattern: [0, 0.15, 0.3, 0.45] }; this.gainNode.gain.setValueAtTime((parseInt(localStorage.getItem('alarm_volume') || '80')) / 100, this.ctx.currentTime); const sched = () => { for (let i = 0; i < 4; i++) { const d = p.pattern[i] || i * 0.1; this._playTone(p.base, p.type, 0.1, d); this._playTone(p.base * 1.5, p.type, 0.08, d + 0.05); } }; sched(); this._alarmInterval = setInterval(sched, 600); },
  stopAlarm() { if (this._alarmInterval) { clearInterval(this._alarmInterval); this._alarmInterval = null; } },
  beep() { this._ensure(); this._playTone(880, 'sine', 0.15); }
};

let alarms = [], editingId = null, selectedDays = [], repeatMode = 'weekly', selectedDates = [];
let calYear = new Date().getFullYear(), calMonth = new Date().getMonth();
let timerRemaining = 300, timerRunning = false, timerInterval = null;
let swRunning = false, swTime = 0, swInterval = null, laps = [];
let is24h = false, ringDuration = 10, ringingAlarmId = null, snoozeTimeout = null;
const $ = id => document.getElementById(id);
const clockTime = $('clockTime'), clockSeconds = $('clockSeconds'), clockDate = $('clockDate');
const alarmsList = $('alarmsList'), emptyAlarms = $('emptyAlarms'), alarmModal = $('alarmModal'), ringingOverlay = $('ringingOverlay');

function updateClock() { const n = new Date(); const h = n.getHours(), m = n.getMinutes(), s = n.getSeconds(); const p = x => String(x).padStart(2, '0'); if (is24h) clockTime.textContent = p(h) + ':' + p(m); else { const a = h >= 12 ? 'PM' : 'AM'; const h12 = h % 12 || 12; clockTime.textContent = p(h12) + ':' + p(m) + ' ' + a; } clockSeconds.textContent = ':' + p(s); clockDate.textContent = n.getFullYear() + '年' + (n.getMonth() + 1) + '月' + n.getDate() + '日 ' + ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][n.getDay()]; }
setInterval(updateClock, 1000); updateClock();

document.querySelectorAll('.tab-btn').forEach(b => { b.addEventListener('click', () => { document.querySelectorAll('.tab-btn').forEach(x => x.classList.remove('active')); document.querySelectorAll('.tab-content').forEach(x => x.classList.remove('active')); b.classList.add('active'); $(b.dataset.tab + 'Content').classList.add('active'); $('addAlarmBtn').style.display = b.dataset.tab === 'alarms' ? 'flex' : 'none'; }); });

function saveAlarms() { localStorage.setItem('alarms', JSON.stringify(alarms)); }
function loadAlarms() { try { alarms = JSON.parse(localStorage.getItem('alarms') || '[]'); } catch { alarms = []; } alarms.forEach(a => { if (a.repeatMode === undefined) a.repeatMode = (a.repeat && a.repeat.length > 0) ? 'weekly' : ''; }); }

function renderAlarms() { alarmsList.innerHTML = ''; const s = [...alarms].sort((a, b) => { const [ah, am] = a.time.split(':').map(Number); const [bh, bm] = b.time.split(':').map(Number); return ah * 60 + am - (bh * 60 + bm); }); if (s.length === 0) { alarmsList.appendChild(emptyAlarms); return; } emptyAlarms.remove(); s.forEach((alarm, idx) => { const ri = alarms.indexOf(alarm); const item = document.createElement('div'); item.className = 'alarm-item' + (alarm.enabled === false ? ' disabled' : ''); const label = alarm.label || '闹钟'; const dn = ['日', '一', '二', '三', '四', '五', '六']; let rs = '仅一次'; if (alarm.repeatMode === 'dates' && alarm.repeatDates && alarm.repeatDates.length > 0) { rs = alarm.repeatDates.slice(0, 3).map(d => d.slice(5)).join(' ') + (alarm.repeatDates.length > 3 ? ' 等' : ''); } else if (alarm.repeat && alarm.repeat.length > 0) { if (alarm.repeat.length === 7) rs = '每天'; else if (alarm.repeat.length === 5 && !alarm.repeat.includes(0) && !alarm.repeat.includes(6)) rs = '工作日'; else if (alarm.repeat.length === 2 && alarm.repeat.includes(0) && alarm.repeat.includes(6)) rs = '周末'; else rs = alarm.repeat.map(d => dn[d]).join(' '); } item.innerHTML = '<div class="alarm-info"><div class="alarm-time">' + alarm.time + '</div><div class="alarm-meta">' + (label !== '闹钟' ? '<span>' + label + '</span><span class="alarm-repeat-dot">·</span>' : '') + '<span>' + rs + '</span>' + ((!alarm.repeat || alarm.repeat.length === 0) && alarm.repeatMode !== 'dates' ? '<span class="alarm-repeat-dot">·</span><span>单次</span>' : '') + '</div></div><div class="alarm-actions"><button class="delete-btn" data-idx="' + ri + '" aria-label="删除"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button><label class="toggle-switch"><input type="checkbox" class="alarm-toggle" data-idx="' + ri + '"' + (alarm.enabled !== false ? ' checked' : '') + '><span class="toggle-track"></span></label></div>'; item.querySelector('.alarm-info').addEventListener('click', () => openEditModal(ri)); alarmsList.appendChild(item); }); document.querySelectorAll('.delete-btn').forEach(b => { b.addEventListener('click', e => { e.stopPropagation(); alarms.splice(parseInt(b.dataset.idx), 1); saveAlarms(); renderAlarms(); }); }); document.querySelectorAll('.alarm-toggle').forEach(t => { t.addEventListener('change', () => { const i = parseInt(t.dataset.idx); if (alarms[i]) { alarms[i].enabled = t.checked; saveAlarms(); renderAlarms(); } }); }); }

function getNextFire(alarm) { const [h, m] = alarm.time.split(':').map(Number); const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m, 0); if (alarm.repeatMode === 'dates' && alarm.repeatDates && alarm.repeatDates.length > 0) { const nt = now.getTime(); const sorted = [...alarm.repeatDates].sort(); for (const ds of sorted) { const d = new Date(ds + 'T' + String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':00'); if (d.getTime() > nt) return d.getTime(); } return null; } else if (alarm.repeat && alarm.repeat.length > 0) { for (let o = 0; o < 8; o++) { const t = new Date(today.getTime() + o * 86400000); if (alarm.repeat.includes(t.getDay()) && (o > 0 || t > now)) return t.getTime(); } } else { if (today > now) return today.getTime(); } return null; }

let lastCheckedMinute = -1;
function checkAlarms() { const now = new Date(); const cm = now.getHours() * 60 + now.getMinutes(); if (cm === lastCheckedMinute) return; lastCheckedMinute = cm; alarms.forEach((alarm, idx) => { if (alarm.enabled === false) return; const [ah, am] = alarm.time.split(':').map(Number); if (ah === now.getHours() && am === now.getMinutes() && now.getSeconds() < 3) { if (alarm.repeatMode === 'dates' && alarm.repeatDates && alarm.repeatDates.length > 0) { const ymd = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0'); if (!alarm.repeatDates.includes(ymd)) return; } triggerAlarm(idx); } }); }
setInterval(checkAlarms, 2000);

function triggerAlarm(idx) { const alarm = alarms[idx]; if (!alarm) return; ringingAlarmId = idx; $('ringingTime').textContent = alarm.time; $('ringingLabel').textContent = alarm.label || '闹钟'; ringingOverlay.classList.add('open'); AudioEngine.startAlarm(alarm.sound || 'classic'); const dur = parseInt(localStorage.getItem('ring_duration') || '10'); if (snoozeTimeout) clearTimeout(snoozeTimeout); snoozeTimeout = setTimeout(() => dismissAlarm(), dur * 60000); if (alarm.vibrate !== false && navigator.vibrate) navigator.vibrate([500, 200, 500, 200, 500]); }
function dismissAlarm() { AudioEngine.stopAlarm(); ringingOverlay.classList.remove('open'); if (snoozeTimeout) { clearTimeout(snoozeTimeout); snoozeTimeout = null; } if (navigator.vibrate) navigator.vibrate(0); const alarm = alarms[ringingAlarmId]; if (alarm) { const isWeek = alarm.repeatMode === 'weekly' && alarm.repeat && alarm.repeat.length > 0; const isDate = alarm.repeatMode === 'dates' && alarm.repeatDates && alarm.repeatDates.length > 0; if (!isWeek && !isDate) { alarm.enabled = false; saveAlarms(); renderAlarms(); } } ringingAlarmId = null; }
function snoozeAlarm() { AudioEngine.stopAlarm(); ringingOverlay.classList.remove('open'); if (snoozeTimeout) clearTimeout(snoozeTimeout); if (navigator.vibrate) navigator.vibrate(0); const idx = ringingAlarmId; setTimeout(() => { if (alarms[idx] && alarms[idx].enabled !== false) triggerAlarm(idx); }, 300000); ringingAlarmId = null; }
$('dismissBtn').addEventListener('click', dismissAlarm);
$('snoozeBtn').addEventListener('click', snoozeAlarm);

function openModal(t) { $('modalTitle').textContent = t; alarmModal.classList.add('open'); }
function closeModal() { alarmModal.classList.remove('open'); editingId = null; selectedDays = []; selectedDates = []; repeatMode = 'weekly'; document.querySelectorAll('.day-btn').forEach(b => b.classList.remove('selected')); document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active')); const _m = document.querySelector('.mode-btn[data-mode="weekly"]'); if (_m) _m.classList.add('active'); const _w = document.getElementById('repeatWeekly'), _d = document.getElementById('repeatDates'); if (_w) _w.style.display = 'block'; if (_d) _d.style.display = 'none'; }
function openAddModal() { editingId = null; const now = new Date(); const h = now.getHours(), m = now.getMinutes(); $('hourDisplay').textContent = String(h).padStart(2, '0'); $('minDisplay').textContent = String(Math.ceil(m / 5) * 5 % 60).padStart(2, '0'); $('alarmLabel').value = ''; $('alarmSound').value = 'classic'; $('alarmVibrate').checked = true; $('alarmSnooze').checked = true; selectedDays = []; selectedDates = []; repeatMode = 'weekly'; document.querySelectorAll('.day-btn').forEach(b => b.classList.remove('selected')); document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active')); const _m = document.querySelector('.mode-btn[data-mode="weekly"]'); if (_m) _m.classList.add('active'); document.getElementById('repeatWeekly').style.display = 'block'; document.getElementById('repeatDates').style.display = 'none'; calYear = now.getFullYear(); calMonth = now.getMonth(); renderCalendar(calYear, calMonth); openModal('新闹钟'); }
function openEditModal(idx) { const a = alarms[idx]; if (!a) return; editingId = idx; const now = new Date(); const [h, m] = a.time.split(':').map(Number); $('hourDisplay').textContent = String(h).padStart(2, '0'); $('minDisplay').textContent = String(m).padStart(2, '0'); $('alarmLabel').value = a.label || ''; $('alarmSound').value = a.sound || 'classic'; $('alarmVibrate').checked = a.vibrate !== false; $('alarmSnooze').checked = a.snooze !== false; selectedDays = a.repeat ? [...a.repeat] : []; selectedDates = a.repeatDates ? [...a.repeatDates] : []; repeatMode = a.repeatMode || 'weekly'; document.querySelectorAll('.mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === repeatMode)); document.getElementById('repeatWeekly').style.display = repeatMode === 'weekly' ? 'block' : 'none'; document.getElementById('repeatDates').style.display = repeatMode === 'dates' ? 'block' : 'none'; document.querySelectorAll('.day-btn').forEach(b => b.classList.toggle('selected', selectedDays.includes(parseInt(b.dataset.day)))); if (selectedDates.length > 0) { calYear = parseInt(selectedDates[0].split('-')[0]); calMonth = parseInt(selectedDates[0].split('-')[1]) - 1; } else { calYear = now.getFullYear(); calMonth = now.getMonth(); } renderCalendar(calYear, calMonth); document.getElementById('calCount').textContent = '已选 ' + selectedDates.length + ' 天'; openModal('编辑闹钟'); }
function saveAlarmFromModal() { const h = parseInt($('hourDisplay').textContent), m = parseInt($('minDisplay').textContent); const label = $('alarmLabel').value.trim(), sound = $('alarmSound').value, vibrate = $('alarmVibrate').checked, snooze = $('alarmSnooze').checked; let repeat, repeatDates, rMode; if (repeatMode === 'dates') { rMode = 'dates'; repeat = []; repeatDates = [...selectedDates]; } else { rMode = 'weekly'; repeat = selectedDays.length > 0 ? [...selectedDays] : []; repeatDates = []; } const data = { time: String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0'), label, sound, vibrate, snooze, enabled: true, repeatMode: rMode, repeat, repeatDates }; if (editingId !== null) alarms[editingId] = { ...alarms[editingId], ...data }; else alarms.push(data); saveAlarms(); renderAlarms(); closeModal(); }
$('addAlarmBtn').addEventListener('click', openAddModal);
$('modalClose').addEventListener('click', closeModal);
$('modalCancel').addEventListener('click', closeModal);
$('modalSave').addEventListener('click', saveAlarmFromModal);
alarmModal.addEventListener('click', e => { if (e.target === alarmModal) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); $('settingsModal').classList.remove('open'); } });
function adjustPicker(dir, el, max) { let v = parseInt(el.textContent) + dir; if (v < 0) v = max; if (v > max) v = 0; el.textContent = String(v).padStart(2, '0'); }
$('hourUp').addEventListener('click', () => adjustPicker(1, $('hourDisplay'), is24h ? 23 : 12));
$('hourDown').addEventListener('click', () => adjustPicker(-1, $('hourDisplay'), is24h ? 23 : 12));
$('minUp').addEventListener('click', () => adjustPicker(1, $('minDisplay'), 59));
$('minDown').addEventListener('click', () => adjustPicker(-1, $('minDisplay'), 59));
document.querySelectorAll('.day-btn').forEach(b => { b.addEventListener('click', () => { const d = parseInt(b.dataset.day); const i = selectedDays.indexOf(d); if (i >= 0) { selectedDays.splice(i, 1); b.classList.remove('selected'); } else { selectedDays.push(d); b.classList.add('selected'); } }); });

function formatDateStr(y, m, d) { return y + '-' + String(m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0'); }
function renderCalendar(year, month) { const grid = document.getElementById('calGrid'), title = document.getElementById('calTitle'); if (!grid) return; title.textContent = year + '年' + (month + 1) + '月'; grid.innerHTML = ''; const fd = new Date(year, month, 1).getDay(), dim = new Date(year, month + 1, 0).getDate(), dip = new Date(year, month, 0).getDate(); const today = new Date(), tStr = formatDateStr(today.getFullYear(), today.getMonth(), today.getDate()); const cells = []; for (let i = fd - 1; i >= 0; i--) cells.push({ day: dip - i, other: true }); for (let d = 1; d <= dim; d++) cells.push({ day: d, other: false }); const rem = 42 - cells.length; for (let d = 1; d <= rem; d++) cells.push({ day: d, other: true }); cells.forEach(cell => { const el = document.createElement('div'); el.className = 'calendar-day'; el.textContent = cell.day; let ds; if (cell.other) { const m2 = cell.day <= new Date(year, month, 0).getDate() ? month - 1 : month + 1; const y2 = m2 < 0 ? year - 1 : (m2 > 11 ? year + 1 : year); const m3 = ((m2 % 12) + 12) % 12; ds = formatDateStr(y2, m3, cell.day); el.dataset.date = ds; el.classList.add('other-month'); } else { ds = formatDateStr(year, month, cell.day); el.dataset.date = ds; } if (ds === tStr) el.classList.add('today'); if (ds < tStr && !cell.other) el.classList.add('past'); if (selectedDates.indexOf(ds) >= 0) el.classList.add('selected'); if (!cell.other && ds >= tStr) { el.addEventListener('click', function () { const ds2 = el.dataset.date; const i = selectedDates.indexOf(ds2); if (i >= 0) { selectedDates.splice(i, 1); el.classList.remove('selected'); } else { selectedDates.push(ds2); selectedDates.sort(); el.classList.add('selected'); } document.getElementById('calCount').textContent = '已选 ' + selectedDates.length + ' 天'; }); } grid.appendChild(el); }); }
const _calP = document.getElementById('calPrev'), _calN = document.getElementById('calNext');
if (_calP) { _calP.addEventListener('click', () => { calMonth--; if (calMonth < 0) { calMonth = 11; calYear--; } renderCalendar(calYear, calMonth); }); _calN.addEventListener('click', () => { calMonth++; if (calMonth > 11) { calMonth = 0; calYear++; } renderCalendar(calYear, calMonth); }); }
document.querySelectorAll('.mode-btn').forEach(b => { b.addEventListener('click', function () { document.querySelectorAll('.mode-btn').forEach(x => x.classList.remove('active')); b.classList.add('active'); repeatMode = b.dataset.mode; document.getElementById('repeatWeekly').style.display = repeatMode === 'weekly' ? 'block' : 'none'; document.getElementById('repeatDates').style.display = repeatMode === 'dates' ? 'block' : 'none'; if (repeatMode === 'dates') renderCalendar(calYear, calMonth); }); });

function updateTimerDisplay() { const m = Math.floor(timerRemaining / 60), s = timerRemaining % 60; $('timerMin').textContent = String(m).padStart(2, '0'); $('timerSec').textContent = String(s).padStart(2, '0'); }
function timerTick() { if (timerRemaining <= 0) { clearInterval(timerInterval); timerInterval = null; timerRunning = false; $('timerStartBtn').textContent = '开始'; $('timerStartBtn').classList.remove('active'); AudioEngine._ensure(); AudioEngine.startAlarm('digital'); setTimeout(() => AudioEngine.stopAlarm(), 5000); if (navigator.vibrate) navigator.vibrate([300, 200, 300, 200, 300]); return; } timerRemaining--; updateTimerDisplay(); }
$('timerStartBtn').addEventListener('click', () => { if (timerRunning) { clearInterval(timerInterval); timerInterval = null; timerRunning = false; $('timerStartBtn').textContent = '继续'; $('timerStartBtn').classList.remove('active'); } else { if (timerRemaining <= 0) timerRemaining = 300; timerRunning = true; timerInterval = setInterval(timerTick, 1000); $('timerStartBtn').textContent = '暂停'; $('timerStartBtn').classList.add('active'); } });
$('timerResetBtn').addEventListener('click', () => { clearInterval(timerInterval); timerInterval = null; timerRunning = false; timerRemaining = 300; updateTimerDisplay(); $('timerStartBtn').textContent = '开始'; $('timerStartBtn').classList.remove('active'); });
document.querySelectorAll('.preset-btn').forEach(b => { b.addEventListener('click', () => { if (timerRunning) return; document.querySelectorAll('.preset-btn').forEach(x => x.classList.remove('active')); b.classList.add('active'); timerRemaining = parseInt(b.dataset.time); updateTimerDisplay(); }); });
document.addEventListener('keydown', e => { if (e.key >= '0' && e.key <= '9') { if (!$('timerContent').classList.contains('active') || timerRunning) return; if (!window._timerBuf) window._timerBuf = ''; window._timerBuf += e.key; if (window._timerBuf.length > 4) window._timerBuf = window._timerBuf.slice(-4); const v = parseInt(window._timerBuf) || 0; const secs = v % 100, mins = Math.floor(v / 100) % 100; if (mins <= 99 && secs <= 59) { timerRemaining = mins * 60 + secs; updateTimerDisplay(); } clearTimeout(window._timerBufClear); window._timerBufClear = setTimeout(() => window._timerBuf = '', 2000); } });

function updateSWDisplay() { const t = swTime; const m = Math.floor(t / 60000), s = Math.floor((t % 60000) / 1000), ms = Math.floor((t % 1000) / 10); $('swMin').textContent = String(m).padStart(2, '0'); $('swSec').textContent = String(s).padStart(2, '0'); $('swMs').textContent = String(ms).padStart(2, '0'); }
function renderLaps() { const list = $('lapsList'); list.innerHTML = ''; [...laps].reverse().forEach((lap, i) => { const idx = laps.length - i; const m = Math.floor(lap / 60000), s = Math.floor((lap % 60000) / 1000), ms = Math.floor((lap % 1000) / 10); const it = document.createElement('div'); it.className = 'lap-item'; it.innerHTML = '<span class="lap-num">计次 ' + idx + '</span><span class="lap-time">' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0') + '.' + String(ms).padStart(2, '0') + '</span>'; list.appendChild(it); }); }
$('swStartBtn').addEventListener('click', () => { if (swRunning) { clearInterval(swInterval); swInterval = null; swRunning = false; $('swStartBtn').textContent = '继续'; $('swStartBtn').classList.remove('active'); laps.push(swTime); renderLaps(); $('lapsContainer').style.display = 'block'; } else { swRunning = true; const st = Date.now() - swTime; swInterval = setInterval(() => { swTime = Date.now() - st; updateSWDisplay(); }, 10); $('swStartBtn').textContent = '计次'; $('swStartBtn').classList.add('active'); } });
$('swResetBtn').addEventListener('click', () => { clearInterval(swInterval); swInterval = null; swRunning = false; swTime = 0; laps = []; updateSWDisplay(); renderLaps(); $('swStartBtn').textContent = '开始'; $('swStartBtn').classList.remove('active'); $('lapsContainer').style.display = 'none'; });
$('settingsBtn').addEventListener('click', () => { $('use24h').checked = is24h; $('ringDuration').value = ringDuration; $('alarmVolume').value = parseInt(localStorage.getItem('alarm_volume') || '80'); $('volumeLabel').textContent = $('alarmVolume').value + '%'; $('settingsModal').classList.add('open'); });
$('settingsClose').addEventListener('click', () => $('settingsModal').classList.remove('open'));
$('settingsModal').addEventListener('click', e => { if (e.target === $('settingsModal')) $('settingsModal').classList.remove('open'); });
$('alarmVolume').addEventListener('input', () => { $('volumeLabel').textContent = $('alarmVolume').value + '%'; });
$('settingsSave').addEventListener('click', () => { is24h = $('use24h').checked; ringDuration = parseInt($('ringDuration').value) || 10; localStorage.setItem('use24h', is24h ? '1' : '0'); localStorage.setItem('ring_duration', String(ringDuration)); localStorage.setItem('alarm_volume', $('alarmVolume').value); updateClock(); $('settingsModal').classList.remove('open'); });

function init() { is24h = localStorage.getItem('use24h') === '1'; ringDuration = parseInt(localStorage.getItem('ring_duration') || '10'); loadAlarms(); renderAlarms(); updateClock(); updateTimerDisplay(); updateSWDisplay(); $('lapsContainer').style.display = 'none'; $('addAlarmBtn').style.display = 'flex'; }

// ─── Native Android Bridge ──────────────────────────────────
var isNative = typeof AndroidAlarm !== 'undefined';
if (isNative) console.log('Native Android: ON');

// Called from Java when alarm fires
window.triggerNativeAlarm = function(alarmId, label, time) {
  document.getElementById('ringingTime').textContent = time || '07:00';
  document.getElementById('ringingLabel').textContent = label || '闹钟';
  document.getElementById('ringingOverlay').classList.add('open');
  AudioEngine.startAlarm('classic');
  if (navigator.vibrate) navigator.vibrate([500, 200, 500, 200, 500]);
};

// Patch: when saving alarm, also register with Android
var __origSave = window.saveAlarmFromModal;
if (__origSave) {
  window.saveAlarmFromModal = function() {
    __origSave();
    if (isNative) {
      try {
        var alarms = JSON.parse(localStorage.getItem('alarms') || '[]');
        alarms.forEach(function(a, i) {
          if (a.enabled !== false) {
            AndroidAlarm.scheduleAlarm('a' + i + '_' + a.time.replace(':',''), a.time, a.label || '闹钟');
          }
        });
      } catch(e) { console.log('Bridge error:', e); }
    }
  };
}

// Patch: dismiss stops native alarm
var __origDismiss = window.dismissAlarm;
if (__origDismiss) {
  window.dismissAlarm = function() {
    if (isNative) { try { AndroidAlarm.dismissAlarm(''); } catch(e) {} }
    __origDismiss();
  };
}
init(); console.log('Alarm Clock ready');
if ('wakeLock' in navigator) { document.addEventListener('visibilitychange', async () => { if (document.visibilityState === 'visible' && document.hasFocus()) { try { await navigator.wakeLock.request('screen'); } catch { } } }); }
document.addEventListener('click', async () => { if ('wakeLock' in navigator && document.visibilityState === 'visible') { try { await navigator.wakeLock.request('screen'); } catch { } } }, { once: false });
