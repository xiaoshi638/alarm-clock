﻿package com.alarmclock.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private WebAppInterface webAppInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(false);
        }

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                handleAlarmIntent();
            }
        });

        webAppInterface = new WebAppInterface(this);
        webView.addJavascriptInterface(webAppInterface, "AndroidAlarm");

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void handleAlarmIntent() {
        Intent intent = getIntent();
        if (intent != null && "com.alarmclock.app.ACTION_ALARM_FIRED".equals(intent.getAction())) {
            String alarmId = intent.getStringExtra("alarm_id");
            String label = intent.getStringExtra("alarm_label");
            String time = intent.getStringExtra("alarm_time");
            if (label == null) label = "闹钟";
            if (time == null) time = "07:00";

            String js = "javascript:(function(){"
                    + "if(window.triggerNativeAlarm) {"
                    + "  window.triggerNativeAlarm('" + jsEscape(alarmId) + "','" + jsEscape(label) + "','" + jsEscape(time) + "');"
                    + "} else {"
                    + "  document.addEventListener('DOMContentLoaded', function(){"
                    + "    window.triggerNativeAlarm('" + jsEscape(alarmId) + "','" + jsEscape(label) + "','" + jsEscape(time) + "');"
                    + "  });"
                    + "}})()";
            webView.evaluateJavascript(js, null);
        }
    }

    private String jsEscape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) handleAlarmIntent();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
