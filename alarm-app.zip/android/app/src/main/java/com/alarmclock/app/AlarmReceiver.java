﻿package com.alarmclock.app;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String alarmId = intent.getStringExtra("alarm_id");
        String label = intent.getStringExtra("alarm_label");
        String time = intent.getStringExtra("alarm_time");
        if (label == null) label = "闹钟";

        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(
                PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP |
                PowerManager.ON_AFTER_RELEASE, "AlarmClock:AlarmWakeLock");
        wl.acquire(10000);

        Intent activityIntent = new Intent(context, MainActivity.class);
        activityIntent.setAction("com.alarmclock.app.ACTION_ALARM_FIRED");
        activityIntent.putExtra("alarm_id", alarmId);
        activityIntent.putExtra("alarm_label", label);
        activityIntent.putExtra("alarm_time", time);
        activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        context.startActivity(activityIntent);

        Intent serviceIntent = new Intent(context, AlarmService.class);
        serviceIntent.putExtra("alarm_id", alarmId);
        serviceIntent.putExtra("alarm_label", label);
        serviceIntent.putExtra("alarm_time", time);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }

        wl.release();
    }
}
