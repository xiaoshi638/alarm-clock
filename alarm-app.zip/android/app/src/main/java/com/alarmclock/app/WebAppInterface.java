﻿package com.alarmclock.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.webkit.JavascriptInterface;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class WebAppInterface {
    private static final String PREFS_NAME = "AlarmPrefs";
    private static final String ALARMS_KEY = "scheduled_alarms";
    private Context context;

    public WebAppInterface(Context context) {
        this.context = context;
    }

    @JavascriptInterface
    public String scheduleAlarm(String id, String timeStr, String label) {
        try {
            String[] parts = timeStr.split(":");
            int hour = Integer.parseInt(parts[0]);
            int minute = Integer.parseInt(parts[1]);

            Calendar now = Calendar.getInstance();
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);

            if (cal.getTimeInMillis() <= now.getTimeInMillis()) {
                cal.add(Calendar.DAY_OF_MONTH, 1);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                if (!am.canScheduleExactAlarms()) {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    return "{\"success\":false,\"error\":\"need_exact_alarm_permission\"}";
                }
            }

            Intent intent = new Intent(context, AlarmReceiver.class);
            intent.setAction("com.alarmclock.app.ACTION_ALARM_FIRED");
            intent.putExtra("alarm_id", id);
            intent.putExtra("alarm_label", label);
            intent.putExtra("alarm_time", timeStr);

            int requestCode = id.hashCode();
            PendingIntent pendingIntent;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            } else {
                pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT);
            }

            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);
            }

            saveAlarmToPrefs(id, timeStr, label, cal.getTimeInMillis());
            Log.d("AlarmClock", "Scheduled alarm " + id + " at " + timeStr);
            return "{\"success\":true}";
        } catch (Exception e) {
            Log.e("AlarmClock", "scheduleAlarm error", e);
            return "{\"success\":false,\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    @JavascriptInterface
    public String cancelAlarm(String id) {
        try {
            int requestCode = id.hashCode();
            Intent intent = new Intent(context, AlarmReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();

            removeAlarmFromPrefs(id);
            Log.d("AlarmClock", "Canceled alarm " + id);
            return "{\"success\":true}";
        } catch (Exception e) {
            return "{\"success\":false,\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    @JavascriptInterface
    public void dismissAlarm(String id) {
        Intent stopIntent = new Intent(context, AlarmService.class);
        context.stopService(stopIntent);
    }

    @JavascriptInterface
    public String getScheduledAlarms() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(ALARMS_KEY, "[]");
    }

    private void saveAlarmToPrefs(String id, String time, String label, long timestamp) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String existing = prefs.getString(ALARMS_KEY, "[]");
        try {
            JSONArray arr = new JSONArray(existing);
            JSONObject obj = new JSONObject();
            obj.put("id", id);
            obj.put("time", time);
            obj.put("label", label);
            obj.put("timestamp", timestamp);
            arr.put(obj);
            prefs.edit().putString(ALARMS_KEY, arr.toString()).apply();
        } catch (Exception e) {
            Log.e("AlarmClock", "saveAlarm error", e);
        }
    }

    private void removeAlarmFromPrefs(String id) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String existing = prefs.getString(ALARMS_KEY, "[]");
        try {
            JSONArray arr = new JSONArray(existing);
            JSONArray result = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (!obj.getString("id").equals(id)) {
                    result.put(obj);
                }
            }
            prefs.edit().putString(ALARMS_KEY, result.toString()).apply();
        } catch (Exception e) {
            Log.e("AlarmClock", "removeAlarm error", e);
        }
    }
}
