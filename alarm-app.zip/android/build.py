﻿import os, sys, subprocess, urllib.request, zipfile, hashlib

GRADLE_VERSION = "8.5"
GRADLE_URL = f"https://services.gradle.org/distributions/gradle-{GRADLE_VERSION}-bin.zip"
CHECKSUM = "3c91b1f0dcc8b83131c3b1b7804ac1c7f1430348"
JAVA_HOME = r"F:\Program Files\Eclipse Adoptium\jdk-25.0.3.9-hotspot"
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
GRADLE_CACHE = os.path.join(os.environ["USERPROFILE"], ".gradle", "wrapper", "dists")

os.environ["JAVA_HOME"] = JAVA_HOME
os.environ["PATH"] = os.path.join(JAVA_HOME, "bin") + os.pathsep + os.environ["PATH"]

def find_java():
    for cmd in ["java.exe", "java"]:
        try:
            r = subprocess.run([cmd, "-version"], capture_output=True, text=True)
            if r.returncode == 0:
                return cmd
        except: pass
    return None

def find_gradle():
    local_gradle = os.path.join(PROJECT_DIR, "gradle-" + GRADLE_VERSION, "bin", "gradle.bat")
    if os.path.exists(local_gradle):
        return local_gradle
    dist_dir = os.path.join(GRADLE_CACHE, f"gradle-{GRADLE_VERSION}-bin")
    if os.path.exists(dist_dir):
        for root, dirs, files in os.walk(dist_dir):
            if "gradle.bat" in files:
                return os.path.join(root, "gradle.bat")
    return None

def download_gradle():
    print(f"Downloading Gradle {GRADLE_VERSION}...")
    zip_path = os.path.join(PROJECT_DIR, f"gradle-{GRADLE_VERSION}-bin.zip")
    try:
        urllib.request.urlretrieve(GRADLE_URL, zip_path)
        print("Extracting...")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(PROJECT_DIR)
        os.remove(zip_path)
        print("Done")
        return True
    except Exception as e:
        print(f"Download failed: {e}")
        # Try mirror
        mirror_urls = [
            f"https://mirrors.cloud.tencent.com/gradle/gradle-{GRADLE_VERSION}-bin.zip",
            f"https://mirrors.aliyun.com/gradle/gradle-{GRADLE_VERSION}-bin.zip"
        ]
        for url in mirror_urls:
            try:
                urllib.request.urlretrieve(url, zip_path)
                with zipfile.ZipFile(zip_path, "r") as zf:
                    zf.extractall(PROJECT_DIR)
                os.remove(zip_path)
                return True
            except:
                continue
        return False

def main():
    java = find_java()
    if not java:
        print("Java not found! Please install JDK 17+")
        sys.exit(1)
    print(f"Java: OK")
    
    gradle = find_gradle()
    if not gradle:
        print("Gradle not found, attempting to download...")
        if not download_gradle():
            print("Please open this project in Android Studio instead.")
            print("Android Studio will automatically download Gradle and the SDK.")
            print(f"\nProject path: {PROJECT_DIR}")
            sys.exit(1)
        gradle = find_gradle()
    
    print(f"Running: {gradle} assembleDebug")
    result = subprocess.run([gradle, "assembleDebug"], cwd=PROJECT_DIR)
    sys.exit(result.returncode)

if __name__ == "__main__":
    main()
